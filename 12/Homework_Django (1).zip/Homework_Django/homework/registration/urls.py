from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('info', views.info),
    path('see-statey', views.see_statey),
]