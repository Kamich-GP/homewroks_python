from django.shortcuts import render
from django.http import HttpResponse

def index(request):
    return render(request, 'registration/main_page.html')

def info(request):
    return render(request, 'registration/info.html')

def see_statey(request):
    return render(request, 'registration/see_statey.html')

